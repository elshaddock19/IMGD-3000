Edward Shaddock
elshaddock@wpi.edu

IMGD 3000 Project 2B

FOLDER STRUCTURE:

Unzipped folder structure:
├── include
│   └ ---.h
├── Makefile
├── Readme.txt
└── src
    ├── test_code
    |   └ ---.cpp
    └── ---.cpp

COMPILING:

Download the elshaddock_project2B.zip file unzip the folder and run 'make' in the unzipped directory to compile
the project.

RUNNING TESTS:

Running make on the command line will create an executable called 'test.out' in the root directory. This program
will output the results of various testing functions which are located in TestRunner.cpp

To run the test file, run ./test.out in your command line from the root directory.
Some output (tests for LogManager) will appear in the generated 'dragonfly-log.txt' file.

Due to the testing of graphics and input events, windows will appear when running test.out.
Check for correct output by interacting inside the window, and close the window to continue to the
other tests.


